<?php

    // DATABASE LOGIN INFORMATIN

        $DB_HOST = '127.0.0.1';
        $DB_UNME = 'test_root';
        $DB_PWRD = 'wololo';
        $DB_NAME = 'vijilis';

    // EMAIL LOGIN INFORMATION

        $GLOBALS['emailToUse'] = "chimerasystemsaz@gmail.com";
        $GLOBALS['emailPassword'] = "ChimeraSystems88!";

    // FILES TO ROOT
    // if in /var/www/html it should be '/'
    // else if in htdocs (XAMPP) make it the folder the site is in
    // so for me, it would be /vijilis/vijilis/

        $GLOBALS['ftr'] = '/vijilis/vijilis/';

?>
