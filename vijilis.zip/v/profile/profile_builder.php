<div class="contentvhr">
    <div class="resourceTitle">
        <h1>I'm Gay</h1>
    </div>
</div>