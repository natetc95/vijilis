<base href="../../">
<div id="Bigmap" style="margin: -15px 0px 0px -17px;"></div>
<script src="public/javascripts/bigmap.js"></script>
<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBkjnCKXG0rhi9sBnXIbFnQYDjcotUnwBw&callback=initMap"></script>