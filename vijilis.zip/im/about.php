<!DOCTYPE html>
<html lang="en">
<body>
  <div id="content">
    <div class="contentIMaboutpageSHELL">
      <div class="aboutpageSCROLL" id="scrollTop">
        <div class="aboutpageSCROLLancestor">
          <img src="/vijilis/public/images/about_img00.jpg" style="width:800px;height:260px;">
        </div>
      </div>
      <div class="contentIMaboutpage" id="skipHereOnScroll">
        <img src="/vijilis/public/images/about_img02.jpg" style="width:800px;height:600px;">
      </div>
      <div class="contentIMaboutpage">
        <img src="/vijilis/public/images/about_img04.jpg" style="width:800px;height:650px;">
      </div>
      <div class="splitSHELL">
        <div class="contentIMaboutpageSPLITleft">
          <img src="/vijilis/public/images/about_img01.jpg" style="width:100%;height:300px;">
        </div>
        <div class="contentIMaboutpageSPLITright">
          <img src="/vijilis/public/images/about_img05.jpg" style="width:100%;height:300px;">
        </div>
      </div>
      <div class="contentIMaboutpage">
        <img src="/vijilis/public/images/about_img03.jpg" style="width:800px;height:180px;">
      </div>
    </div>
  </div>
</body>
</html>
