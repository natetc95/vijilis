<!DOCTYPE html>
<html lang="en">
<body>
  <div id="content">
      <div class="contentvhr">
        Welcome to the Incident Manager Preferences page!
      </div>
  </div>
</body>
</html>
